// TCLens Content Script v5 - Shadow DOM Implementation
const API_BASE_URL = 'http://localhost:3000';

// Global reference for the shadow root
let tclensShadowRoot = null;

// Initialize Shadow DOM root
function initShadow() {
    if (tclensShadowRoot) return tclensShadowRoot;

    const host = document.createElement("div");
    host.id = "tclens-root";
    // Ensure the host itself doesn't affect layout
    host.style.cssText = "position: absolute; top: 0; left: 0; width: 0; height: 0; z-index: 2147483647;";
    document.body.appendChild(host);

    tclensShadowRoot = host.attachShadow({ mode: 'open' });

    // Inject Shared Styles
    const style = document.createElement('style');
    style.textContent = `
        :host {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            text-rendering: optimizeLegibility;
            -webkit-font-smoothing: antialiased;
        }

        .tclens-badge {
            position: fixed; bottom: 20px; right: 20px; z-index: 2147483647;
            background: #0f172a; color: white; padding: 16px; border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            display: flex; align-items: center; gap: 12px; animation: slideIn 0.3s ease-out;
            cursor: pointer; transition: transform 0.2s; max-width: 320px;
            pointer-events: auto;
        }

        .tclens-badge:hover { transform: scale(1.02); }

        .tclens-overlay {
            position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0, 0, 0, 0.5); z-index: 2147483646;
            display: flex; align-items: center; justify-content: center;
            backdrop-filter: blur(4px);
            pointer-events: auto;
        }

        .tclens-popup {
            background: white; border-radius: 20px; padding: 32px;
            max-width: 650px; width: 90%; max-height: 85vh; overflow-y: auto;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            position: relative; color: #1e293b;
            line-height: 1.5;
        }

        .tclens-close-btn {
            background: none; border: none; color: #64748b; cursor: pointer;
            font-size: 24px; padding: 8px; border-radius: 8px;
            transition: background 0.2s;
        }

        .tclens-close-btn:hover { background: #f1f5f9; }

        .warning-card {
            padding: 16px; background: #fffbeb; border-left: 4px solid #f59e0b;
            margin: 12px 0; border-radius: 8px;
        }

        @keyframes slideIn { 
            from { transform: translateY(20px); opacity: 0; } 
            to { transform: translateY(0); opacity: 1; } 
        }
    `;
    tclensShadowRoot.appendChild(style);

    return tclensShadowRoot;
}

// Extract text NON-DESTRUCTIVELY
function extractPageText() {
    // We just take body.innerText directly. No need to remove tags from live DOM.
    // Host styles are preserved because we don't call el.remove() anymore.
    const bodyText = document.body.innerText || "";
    return bodyText.substring(0, 50000);
}

function showBadge(detectionResult) {
    const root = initShadow();
    if (root.getElementById("tclens-badge")) return;

    const badge = document.createElement("div");
    badge.id = "tclens-badge";
    badge.className = "tclens-badge";

    const docType = detectionResult.document_type || "Legal Content";
    const confidence = detectionResult.confidence || 0;

    badge.innerHTML = `
        <div style="font-size: 24px;">🛡️</div>
        <div style="flex: 1;">
            <div style="font-weight: 800; font-size: 14px; letter-spacing: -0.01em;">${docType} Detected</div>
            <div style="font-size: 12px; color: #94a3b8;">Confidence: ${confidence}% • Click to explore</div>
        </div>
        <button id="tclens-close" class="tclens-close-btn" style="font-size: 18px;">×</button>
    `;

    badge.onclick = (e) => {
        if (e.target.id !== "tclens-close") {
            chrome.runtime.sendMessage({ action: "open_popup" });
        }
    };

    root.appendChild(badge);

    root.getElementById("tclens-close").onclick = (e) => {
        e.stopPropagation();
        badge.remove();
    };
}

function showPopup(detectionResult) {
    const root = initShadow();
    if (root.getElementById("tclens-overlay")) return;

    const overlay = document.createElement("div");
    overlay.id = "tclens-overlay";
    overlay.className = "tclens-overlay";

    const riskScore = detectionResult.risk_score || 0;
    const riskColor = riskScore >= 75 ? '#ef4444' : riskScore >= 50 ? '#f59e0b' : '#10b981';

    let warningsHtml = '';
    if (detectionResult.critical_warnings) {
        Object.entries(detectionResult.critical_warnings).forEach(([key, warning]) => {
            if (warning.value) {
                warningsHtml += `
                    <div class="warning-card">
                        <strong style="color: #92400e; display: block; margin-bottom: 4px;">${key.replace(/_/g, ' ').toUpperCase()}</strong>
                        <p style="margin: 0; font-size: 14px; color: #b45309;">${warning.reason}</p>
                    </div>
                `;
            }
        });
    }

    let takeawaysHtml = '';
    if (detectionResult.key_takeaways?.length > 0) {
        takeawaysHtml = '<ul style="margin: 16px 0; padding-left: 20px; color: #475569;">';
        detectionResult.key_takeaways.forEach(item => {
            takeawaysHtml += `<li style="margin: 8px 0;">${item}</li>`;
        });
        takeawaysHtml += '</ul>';
    }

    overlay.innerHTML = `
        <div class="tclens-popup">
            <button id="tclens-popup-close" class="tclens-close-btn" style="position: absolute; top: 20px; right: 20px;">×</button>
            <div style="margin-bottom: 28px;">
                <h2 style="margin: 0 0 4px 0; font-size: 24px; font-weight: 900; color: #0f172a;">${detectionResult.document_type || 'Analysis Report'}</h2>
                <div style="display: flex; align-items: baseline; gap: 8px;">
                    <span style="font-size: 14px; color: #64748b; font-weight: 600;">Risk Score:</span>
                    <span style="font-size: 36px; font-weight: 900; color: ${riskColor};">${riskScore}</span>
                    <span style="font-size: 14px; color: #94a3b8;">/ 100</span>
                </div>
            </div>
            
            ${detectionResult.short_summary ? `
                <div style="margin: 24px 0; padding: 20px; background: #f8fafc; border-radius: 12px; border: 1px solid #f1f5f9;">
                    <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em;">AI Summary</h3>
                    <p style="margin: 0; font-size: 15px; line-height: 1.6; color: #334155;">${detectionResult.short_summary}</p>
                </div>
            ` : ''}
            
            ${takeawaysHtml ? `
                <div style="margin: 24px 0;">
                    <h3 style="margin: 0 0 8px 0; font-size: 16px; font-weight: 700;">Key Insights</h3>
                    ${takeawaysHtml}
                </div>
            ` : ''}
            
            ${warningsHtml ? `
                <div style="margin: 24px 0;">
                    <h3 style="margin: 0 0 8px 0; font-size: 16px; font-weight: 700; color: #dc2626;">Red Flags</h3>
                    ${warningsHtml}
                </div>
            ` : ''}
            
            <div style="margin-top: 32px; display: flex; flex-direction: column; gap: 12px;">
                ${detectionResult.cta_text ? `
                    <button id="tclens-cta" style="width: 100%; padding: 16px; background: #0f172a; color: white; border: none; border-radius: 14px; font-weight: 700; cursor: pointer; transition: background 0.2s;">
                        ${detectionResult.cta_text}
                    </button>
                ` : ''}
                <p style="margin: 0; font-size: 12px; color: #94a3b8; text-align: center;">${detectionResult.disclaimer || 'Analysis provided for informational purposes only.'}</p>
            </div>
        </div>
    `;

    root.appendChild(overlay);

    root.getElementById("tclens-popup-close").onclick = () => overlay.remove();
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };

    const ctaEl = root.getElementById("tclens-cta");
    if (ctaEl) {
        ctaEl.onclick = () => chrome.runtime.sendMessage({ action: "open_full_report" });
    }
}

async function detectLegalContent() {
    try {
        const pageText = extractPageText();
        const response = await fetch(`${API_BASE_URL}/api/extension/detect`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                page_text: pageText,
                url: window.location.href,
                title: document.title
            })
        });

        if (!response.ok) return;

        const result = await response.json();

        if (result.trigger_recommendation === 'show_popup') {
            if (result.short_summary) {
                showPopup(result);
            } else {
                const analyzeResponse = await fetch(`${API_BASE_URL}/api/extension/analyze`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ page_text: pageText, url: window.location.href })
                });
                if (analyzeResponse.ok) {
                    showPopup(await analyzeResponse.json());
                }
            }
        } else if (result.trigger_recommendation === 'show_badge') {
            showBadge(result);
        }

        chrome.runtime.sendMessage({ action: "detection_complete", result });
    } catch (error) {
        console.error('TCLens: Detection failed', error);
    }
}

// Startup
setTimeout(detectLegalContent, 2000);

let lastUrl = location.href;
new MutationObserver(() => {
    if (location.href !== lastUrl) {
        lastUrl = location.href;
        setTimeout(detectLegalContent, 2000);
    }
}).observe(document, { subtree: true, childList: true });
