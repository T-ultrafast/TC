// TCLens Service Worker
// Handles background tasks and API proxying if needed in the future.

chrome.runtime.onInstalled.addListener(() => {
    console.log("TCLens extension installed.");
});

// Listener for messages from content scripts or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "open_popup") {
        // Open the extension popup window if possible, or just log
        console.log("Open popup requested");
    }
});
